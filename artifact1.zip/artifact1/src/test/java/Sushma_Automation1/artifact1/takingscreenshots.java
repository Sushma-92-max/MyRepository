package Sushma_Automation1.artifact1;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class takingscreenshots {

	public static void main(String[] args) throws IOException {
		WebDriver d = new ChromeDriver();
		d.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
	d.manage().window().maximize();
	TakesScreenshot ss = (TakesScreenshot)d;
	File f = ss.getScreenshotAs(OutputType.FILE);
	File des = new File("C:\\Users\\HP\\Pictures\\Takescreenshots\\First.jpeg");
    FileUtils.copyFile(f,des);
	}

}
