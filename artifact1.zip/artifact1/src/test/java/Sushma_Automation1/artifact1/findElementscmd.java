package Sushma_Automation1.artifact1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class findElementscmd {

public static void main(String[] args) throws InterruptedException {
		
		WebDriver D = new ChromeDriver();
		
		D.get("https://demo.automationtesting.in/Register.html");
		
		D.manage().window().maximize();
		
		Thread.sleep(3000);
		
		List<WebElement> li = D.findElements(By.tagName("a"));
		int x = li.size();
		System.out.println("The total number of links in the web page are" +x);
	}

}
