package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class selectvalueofdropdown {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver D = new ChromeDriver();
		D.get("https://demo.automationtesting.in/Register.html");
		D.manage().window().maximize();
		Select s = new Select(D.findElement(By.xpath("//select[@id='Skills']")));
		//s.selectByIndex(1);
		//s.selectByValue("Excel");
		s.selectByVisibleText("FileMaker Pro");
		Thread.sleep(2000);
		D.quit();

	}

}
