package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class findElementcmd {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver D = new ChromeDriver();
		
		D.get("https://demo.automationtesting.in/Register.html");
		
		D.manage().window().maximize();
		
		Thread.sleep(3000);

		WebElement E = D.findElement(By.xpath("//input[@placeholder='First Name']"));
		
		E.sendKeys("Web");
		
		Thread.sleep(1500);
		
        WebElement El = D.findElement(By.xpath("//input[@placeholder='Last Name']"));
		
		El.sendKeys("Element");
		
		Thread.sleep(3000);
		
		E.clear();
		El.clear();
		
		D.close(); 
		
	}

}
