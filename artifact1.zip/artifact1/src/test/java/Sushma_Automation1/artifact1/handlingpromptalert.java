package Sushma_Automation1.artifact1;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class handlingpromptalert {

	public static void main(String[] args) throws InterruptedException {
		WebDriver D =new ChromeDriver();
		D.get("https://demo.automationtesting.in/Alerts.html");
		D.manage().window().maximize();
		D.findElement(By.xpath(" //a[@href='#Textbox']")).click();
		D.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Alert a = D.switchTo().alert();
		a.sendKeys("Vasundhara");
		a.accept();
		String s = D.findElement(By.xpath("//p[@id='demo1']")).getText();
		System.out.println(s);
		Thread.sleep(3000);
	}

}
