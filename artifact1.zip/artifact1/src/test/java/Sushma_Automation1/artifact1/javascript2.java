package Sushma_Automation1.artifact1;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class javascript2 {

		public static void main(String[] args) {
			WebDriver d =new ChromeDriver();
			d.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
			d.manage().window().maximize();
	
			JavascriptExecutor j = (JavascriptExecutor)d;
			j.executeScript("document.getElementById('name').value='Saurabh'", "");
	}

}
