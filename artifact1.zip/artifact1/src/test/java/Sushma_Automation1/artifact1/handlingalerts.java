package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class handlingalerts {

	public static void main(String[] args) throws InterruptedException {
		WebDriver D =new ChromeDriver();
		D.get("https://demo.automationtesting.in/Alerts.html");
		D.manage().window().maximize();
		WebElement E = D.findElement(By.xpath("//button[@class='btn btn-danger']"));
		if(E.isDisplayed()==true && E.isEnabled()==true)
		{
			E.click();
		}
		Thread.sleep(3000);
        D.switchTo().alert().accept();
        Thread.sleep(3000);
        D.quit();
	}

}
