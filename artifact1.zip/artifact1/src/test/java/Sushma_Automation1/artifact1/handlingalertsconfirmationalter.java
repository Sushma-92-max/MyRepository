package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class handlingalertsconfirmationalter {

	public static void main(String[] args) throws InterruptedException {
			WebDriver D =new ChromeDriver();
			D.get("https://demo.automationtesting.in/Alerts.html");
			D.manage().window().maximize();
			D.findElement(By.xpath("//a[@href='#CancelTab']")).click();
		    D.findElement(By.xpath("//button[@class='btn btn-primary']")).click(); 
//			D.switchTo().alert().accept();
//			String value = D.findElement(By.xpath(" //p[@id='demo']")).getText();
//		    System.out.println(value);
//			if(value.contains("Ok"))
//			{
//				System.out.println("You pressed OK");
//			}
//			else
//			{
//				System.out.println("You pressed Cancel");
//			}
		    D.switchTo().alert().dismiss();
			String value = D.findElement(By.xpath(" //p[@id='demo']")).getText();
		    System.out.println(value);
			if(value.contains("cancel"))
			{
				System.out.println("You pressed OK");
			}
			else
			{
				System.out.println("You pressed Cancel");
			}
			Thread.sleep(3000);
	 
	        D.quit();
		}

	}

