package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class getattributecmd {

		public static void main(String[] args) throws InterruptedException { //throws InterruptedException {
			WebDriver dr = new ChromeDriver();
			dr.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
			dr.manage().window().maximize();
			Thread.sleep(1500);
		
			
			WebElement ee = dr.findElement(By.xpath("//input[@id='name']"));
			String a = ee.getAttribute("id");
			System.out.println("The attribute value of id is : " +a);
			dr.quit();

	}

}
