package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class getTagnamecmd {

	public static void main(String[] args) throws InterruptedException { //throws InterruptedException {
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		dr.manage().window().maximize();
		Thread.sleep(1500);
	
		
		WebElement ee = dr.findElement(By.id("practiceForm"));
		String ss= ee.getTagName();
		System.out.println("The tagname of the attribute : " +ss);
		
		Dimension d = ee.getSize();
		System.out.println("Height of the web element is : " +d.height);
		System.out.println("Width of the web element is : " +d.width);
		
		Point p = ee.getLocation();
		System.out.println("X coordinate is : " +p.x);
		System.out.println("Y coordinate is : " +p.y);
		
		Thread.sleep(2000);
		dr.quit();
	}

}
