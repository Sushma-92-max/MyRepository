package Sushma_Automation1.artifact1;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class switchwindows {

	public static void main(String[] args) {
		WebDriver d =new ChromeDriver();
		d.get("https://demo.automationtesting.in/Windows.html");
		d.manage().window().maximize();
		String s = d.getWindowHandle();
		System.out.println("The window ID is : "+s);
		
		d.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		
		Set<String> set = d.getWindowHandles();
		System.out.println("The Window ID's are : ");
		for(String s1:set)
		{
			System.out.println(s1);
		}
			
		Iterator <String> I = set.iterator();
		while(I.hasNext())
		{
			String childwindow = I.next();
			if(!s.equals(childwindow))
			{
				d.switchTo().window(childwindow);
				String Title = d.getTitle();
				System.out.println("The title of the page is :" +Title);
				d.findElement(By.xpath("//a[text()='Register now!']")).click();
			}
		}
		d.switchTo().window(s);
		String title = d.getTitle();
		System.out.println("The title of the page is :" +title);
		

	}

}
