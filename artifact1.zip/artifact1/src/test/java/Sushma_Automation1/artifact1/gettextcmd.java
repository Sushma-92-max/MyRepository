package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class gettextcmd {

	public static void main(String[] args) throws InterruptedException { //throws InterruptedException {
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.google.com");
		dr.manage().window().maximize();
		Thread.sleep(1500);
		String S="";
		
		WebElement E = dr.findElement(By.xpath("//a[text()='Gmail']"));
		if(E.isDisplayed()==true && E.isEnabled()==true )
		{
			S = E.getText();
		}

		System.out.println("The text is :"+S);
	}

}
