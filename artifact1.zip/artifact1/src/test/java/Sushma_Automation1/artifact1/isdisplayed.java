package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class isdisplayed {

	public static void main(String[] args) throws InterruptedException { //throws InterruptedException {
		WebDriver dr = new ChromeDriver();
		dr.get("https://demo.automationtesting.in/Register.html");
		dr.manage().window().maximize();
		//Thread.sleep(3000);
		
		boolean s= dr.findElement(By.id("checkbox1")).isDisplayed();
        System.out.println("Is the cricket checkbox displayed? "+s);
        if(s)
        {
        	dr.findElement(By.id("checkbox1")).click();
        }
        Thread.sleep(1500);
        boolean b= dr.findElement(By.id("checkbox1")).isSelected();
        if(b) {
        	System.out.println("Cricket is selected");
        }
        else
        {
        	System.out.println("Cricket is not selected");
        }
        Thread.sleep(1500);
        boolean g = dr.findElement(By.xpath("//label[text()='Email address*']//following::input[@type='email']")).isEnabled();
        if(g)
        {
        	Thread.sleep(1500); 
          WebElement el = dr.findElement(By.xpath("//label[text()='Email address*']//following::input[@type='email']"));
          el.sendKeys("susoknh@gmai.com");
        }
        
        
	}

}
