package Sushma_Automation1.artifact1;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class brokenlinkspgm {

	public static void main(String[] args) throws IOException {
		WebDriver d = new ChromeDriver();
		d.get("https://bstackdemo.com/");
		d.manage().window().maximize();
		List <WebElement> el = d.findElements(By.tagName("a"));
		for(WebElement x : el)
		{
			System.out.println(x.getText());
			String Url = x.getAttribute("href");
			verifyLink(Url);
			
		}
		d.close();
	}

	public static void verifyLink(String Url) throws IOException {
		URL link = new URL(Url);
		HttpURLConnection  hc = (HttpURLConnection)link.openConnection();
		hc.setConnectTimeout(3000);
		hc.connect();
		if(hc.getResponseCode()==200)
		{
			System.out.println(Url + "  "+hc.getResponseMessage());
		}
		else
		{
			System.out.println("Broken Link "+Url+ "  " +hc.getResponseMessage());
		}
	} 
}
