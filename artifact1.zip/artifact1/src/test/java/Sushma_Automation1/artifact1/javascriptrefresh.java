package Sushma_Automation1.artifact1;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class javascriptrefresh {

	public static void main(String[] args) throws InterruptedException {
		WebDriver d =new ChromeDriver();
		d.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		d.manage().window().maximize();

		Thread.sleep(3000);
		JavascriptExecutor j = (JavascriptExecutor)d;
		j.executeScript("history.go(0)");

		String title = j.executeScript("return document.title").toString();
		System.out.println("The Title of the page is : "+title);
		
	}

}
