package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class actionsKeyboard {

	public static void main(String[] args) throws InterruptedException {
		WebDriver d = new ChromeDriver();
		d.get("https://demoqa.com/text-box");
		d.manage().window().maximize();
	
		Actions a = new Actions (d);
		d.findElement(By.xpath("//input[@id='userName']")).sendKeys("Automation");
		d.findElement(By.xpath("//input[@id='userEmail']")).sendKeys("auto@ggg.com");
		WebElement from = d.findElement(By.xpath("//textarea[@placeholder='Current Address']"));
		from.sendKeys("328,4th main, jdcin, hh-09");
	  d.findElement(By.xpath("//textarea[@id='permanentAddress']"));
		//select content
		a.keyDown(Keys.CONTROL);
		a.sendKeys("a");
		a.keyUp(Keys.CONTROL);
		a.build().perform();
		
		//copy content
	     a.keyDown(Keys.CONTROL);
		 a.sendKeys("c");
		 a.keyUp(Keys.CONTROL);
		 a.build().perform();
		
       //press tab button
		a.keyDown(Keys.TAB);
		a.build().perform();
		Thread.sleep(3000);
		
		//paste content
	     a.keyDown(Keys.CONTROL);
		 a.sendKeys("v");
		 a.keyUp(Keys.CONTROL);
		 a.build().perform();
		 
		 Thread.sleep(3000);
		 
		 d.quit();
				
	}

}
