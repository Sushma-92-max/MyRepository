package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class mousehoveraction {
		public static void main(String[] args) throws InterruptedException {
			WebDriver d = new ChromeDriver();
			d.get("https://www.flipkart.com/");
			d.manage().window().maximize();
			WebElement e = d.findElement(By.xpath("//span[text()='Two Wheelers']"));
			Actions a = new Actions (d);
			a.moveToElement(e).build().perform();
			d.findElement(By.xpath("//*[text()='Electric Vehicles']")).click();
	}

}
