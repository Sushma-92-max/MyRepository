package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class switchframes {

	public static void main(String[] args) throws InterruptedException {
		WebDriver d = new ChromeDriver();
d.get("https://demo.automationtesting.in/Frames.html");		
d.manage().window().maximize();

d.switchTo().frame("singleframe");
d.findElement(By.xpath("//input[@type='text']")).sendKeys("Hello");
Thread.sleep(3000);
d.switchTo().defaultContent();
	}

}
