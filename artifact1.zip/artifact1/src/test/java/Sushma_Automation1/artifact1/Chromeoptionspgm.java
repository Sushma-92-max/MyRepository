package Sushma_Automation1.artifact1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Chromeoptionspgm {

	public static void main(String[] args) {
		ChromeOptions o = new ChromeOptions();
o.addArguments("start-maximize");
o.addArguments("incognito");
o.addArguments("disable-popup-blocking");
o.addArguments("version");
o.addArguments("headless");
WebDriver d  = new ChromeDriver(o);
d.get("https://www.google.com");
String t = d.getTitle();
System.out.println("Title of the web page is  "+t);
	}

}
