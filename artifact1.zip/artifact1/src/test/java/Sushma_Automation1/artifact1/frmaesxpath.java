package Sushma_Automation1.artifact1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class frmaesxpath {

	public static void main(String[] args) throws InterruptedException {
		WebDriver d = new ChromeDriver();
		d.get("https://demo.automationtesting.in/Frames.html");		
		d.manage().window().maximize();
		
		List <WebElement> L = d.findElements(By.tagName("iframe"));
		System.out.println("Total number of frames are : "+L.size());
		d.findElement(By.xpath("//a[@href=\"#Multiple\"]")).click();
		d.switchTo().frame(d.findElement(By.xpath("//iframe[@src='MultipleFrames.html']")));
		d.switchTo().frame(d.findElement(By.xpath("//iframe[@src='SingleFrame.html']")));
		d.findElement(By.xpath("//input[@type='text']")).sendKeys("Entered Text");
		Thread.sleep(3000);
		d.switchTo().defaultContent();
		d.findElement(By.xpath("//a[@href='#Single']")).click();
	}

}
