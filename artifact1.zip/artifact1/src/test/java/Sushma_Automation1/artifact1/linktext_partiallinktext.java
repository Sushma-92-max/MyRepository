package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class linktext_partiallinktext {

		public static void main(String[] args) throws InterruptedException { 
			WebDriver dr = new ChromeDriver();
			dr.get("https://demoqa.com/links");
			dr.manage().window().maximize();
			
			WebElement E = dr.findElement(By.linkText("Home"));
			if(E.isDisplayed()==true && E.isEnabled()==true) {
				E.click();
				System.out.println("Link found by LinkText");
			}
			
			Thread.sleep(2000);

			WebElement El = dr.findElement(By.partialLinkText("Hom"));
			if(El.isDisplayed()==true && El.isEnabled()==true) {
				El.click();
				System.out.println("Link found by PartialLinkText");
			}
	}

}
