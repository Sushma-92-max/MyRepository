package Sushma_Automation1.artifact1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class dropdownisMultiple {

	public static void main(String[] args) throws InterruptedException {
		WebDriver D =new ChromeDriver();
		D.get("https://www.techlistic.com/p/selenium-practice-form.html");
		D.manage().window().maximize();
		WebElement E = D.findElement(By.xpath("//select[@id='selenium_commands']"));
		Select s = new Select(E);
		
		if(s.isMultiple()==true)
		{
			s.selectByIndex(0);
			s.selectByIndex(3);
//		s.selectByValue("WebElement Commands");
		s.selectByVisibleText("Navigation Commands");
			
			List <WebElement> l = s.getOptions();
			System.out.println("List of options : ");
			
			
			for(WebElement x:l)
			{
				System.out.println(x.getText());
			}
            
			List <WebElement> l1 = s.getAllSelectedOptions();
			System.out.println("List of All selected options : ");
			
			for(WebElement x:l1)
			{
				System.out.println(x.getText());
			}
			
			WebElement E2 = s.getFirstSelectedOption();
			System.out.println("The First Selected Option is : " +E2.getText());
			
			Thread.sleep(3000);
			
			s.deselectAll();
		}

	}

}
