package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class actionex1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver d = new ChromeDriver();
		d.get("https://demo.automationtesting.in/Register.html");
		d.manage().window().maximize();
		
		Actions a = new Actions (d);
		WebElement e = d.findElement(By.xpath("//input[@value='Male']"));
		Thread.sleep(2000);
	a.moveToElement(e).click().perform();
	Thread.sleep(2000);
	WebElement e1 = d.findElement(By.xpath("//textarea[@rows='3']"));
	a.doubleClick(e1).perform();
	
	Thread.sleep(2000);
WebElement e2 = d.findElement(By.xpath("//input[@placeholder='First Name']"));
a.contextClick(e2).perform();
		
		
	}

}
