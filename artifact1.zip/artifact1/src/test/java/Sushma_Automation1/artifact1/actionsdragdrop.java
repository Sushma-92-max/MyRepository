package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class actionsdragdrop {

	public static void main(String[] args) {
		WebDriver d = new ChromeDriver();
		d.get("https://demo.guru99.com/test/drag_drop.html");
		d.manage().window().maximize();
		
		Actions a = new Actions (d);
		WebElement s1 = d.findElement(By.xpath("//a[@class='button button-orange']//parent::li[@id='credit2']"));
		WebElement t1 = d.findElement(By.xpath("//li[@class='placeholder']//parent::ol[@id='bank']"));
		a.dragAndDrop(s1, t1).build().perform();
		
	}

}
