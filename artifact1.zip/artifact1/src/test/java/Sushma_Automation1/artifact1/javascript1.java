package Sushma_Automation1.artifact1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class javascript1 {

	public static void main(String[] args) {
		WebDriver d =new ChromeDriver();
		d.get("https://demo.automationtesting.in/Register.html");
		d.manage().window().maximize();
		
		JavascriptExecutor j = (JavascriptExecutor)d;
		j.executeScript("window.scrollBy(0,300)", "");
		
		
		WebElement e = d.findElement(By.xpath("//button[@id='submitbtn']"));
		j.executeScript("arguments[0].click()", e);
	}

}
